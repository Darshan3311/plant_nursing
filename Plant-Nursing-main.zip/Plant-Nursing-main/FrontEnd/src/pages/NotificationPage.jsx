import React from 'react'

function NotificationPage() {
  return (
    <div>NotificationPage</div>
  )
}

export default NotificationPage