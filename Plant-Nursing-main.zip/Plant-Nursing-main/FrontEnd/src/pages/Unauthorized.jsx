import React from 'react'

function Unauthorized() {
  return (
    <div>Unauthorized</div>
  )
}

export default Unauthorized