import React from 'react'

function ProfilePage() {
  return (
    <div>ProfilePage</div>
  )
}

export default ProfilePage