// import express from 'express';
// import cors from 'cors';

// import { login } from '../controllers/auth.controller.js';

// const router = express.Router();

// router.post('/login', login);

// export default router;


// // src/app.js (was: authrout.js)
// import dotenv from 'dotenv';
// import authRoutes from './routes/auth.routes.js';

// dotenv.config();

// const app = express();

// app.use(cors({
//   origin: process.env.FRONTEND_URL,
//   credentials: true,
// }));

// app.use(express.json());

// app.use('/api/auth', authRoutes);

// export default app;
